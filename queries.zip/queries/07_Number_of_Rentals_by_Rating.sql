-- 07_Number_of_Rentals_by_Rating
select Rating, count(p.payment_id) as Rental_Count
from sakila.payment as p
join sakila.rental as r on p.rental_id = r.rental_id
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film as f on i.film_id = f.film_id
group by Rating