-- 10_Top_3_Films_Having_Highest_Payment_in_Each_10_Highest_Payed_Country
with Top_Country as
(select co.Country, sum(p.amount) as Country_Payment, 
row_number() over(order by sum(p.amount) DESC) as Country_Rank
from sakila.payment as p 
join sakila.customer as c on p.customer_id = c.customer_id
join sakila.address as a on c.address_id = a.address_id
join sakila.city as ct on a.city_id = ct.city_id
join sakila.country as co on ct.country_id = co.country_id
group by co.country_id),
Top_Films as
(select f.Title, co.Country, sum(p.amount) as Film_Payment,
row_number() over (partition by co.Country order by sum(p.amount) DESC) as Film_Rank
from sakila.customer as c
join sakila.payment as p on p.customer_id = c.customer_id
join sakila.rental as r on p.rental_id = r.rental_id
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film as f on i.film_id = f.film_id
join sakila.address as a on c.address_id = a.address_id
join sakila.city as ct on a.city_id = ct.city_id
join sakila.country as co on ct.country_id = co.country_id
group by f.film_id, co.country_id)
select Title, tf.Country, Film_Payment, Film_Rank
from Top_Films as tf
join Top_Country as tc on tf.country = tc.country
where tc.Country_Rank <= 10
and tf.Film_Rank <= 3
order by tc.Country_Payment DESC, tf.Film_Payment DESC