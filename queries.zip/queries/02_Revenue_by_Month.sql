-- 02_Revenue_by_Month
select date_format(payment_date, '%M-%Y') as Month,
sum(amount) as Revenue 
from sakila.payment
group by month
order by month;