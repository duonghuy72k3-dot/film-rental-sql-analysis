-- 08_Top_10_Most_Rented_Films
with Rented_Film as
(select Title, count(p.payment_id) as Number_of_Rentals
from sakila.payment as p 
join sakila.rental as r on p.rental_id = r.rental_id
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film as f on i.film_id = f.film_id
group by Title)
select Title, Number_of_Rentals,
row_number() over(order by Number_of_Rentals DESC) as Ranking
from Rented_Film
limit 10