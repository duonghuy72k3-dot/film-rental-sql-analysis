-- 05_Ranking_Revenue_by_Category
with payment_category as
(select c.Name as Category, sum(p.amount) as Revenue
from sakila.payment as p 
join sakila.rental as r on p.rental_id = r.rental_id
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film_category as fc on i.film_id = fc.film_id
join sakila.category as c on fc.category_id = c.category_id 
group by c.category_id)
select Category, Revenue,
rank() over(order by Revenue DESC) as Ranking
from payment_category