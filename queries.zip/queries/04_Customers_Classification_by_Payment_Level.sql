-- 04_Customers_Classification_by_Payment_Level
select concat(c.first_name, ' ', c.last_name) as Full_Name, Email,
sum(p.amount) as Total_Payment,
case
when sum(p.amount) >= 180 then 'Gold'
when sum(p.amount) between 150 and 180 then 'Silver'
when sum(p.amount) between 120 and 180 then 'Bronze'
else ' '
end as Customer_Level
from sakila.payment as p
join sakila.customer as c on p.customer_id = c.customer_id
group by c.customer_id
order by Total_Payment