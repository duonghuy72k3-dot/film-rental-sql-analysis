-- 01_Total_Revenue
select sum(amount) as Total_Revenue 
from sakila.payment;