-- 06_Top_10_Actors_Generating_the_Highest_Revenue
with Actors_Revenue as
(select concat(a.first_name, ' ', a.last_name) as Full_name, 
sum(p.amount) as Revenue 
from sakila.payment as p
join sakila.rental as r on p.rental_id = r.rental_id
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film_actor as f on i.film_id = f.film_id
join sakila.actor as a on f.actor_id = a.actor_id
group by a.actor_id)
select Full_name, Revenue,
Rank() over(order by Revenue DESC) as Ranking
from Actors_Revenue
limit 10