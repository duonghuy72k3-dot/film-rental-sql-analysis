-- 03_Countries_with_Payments_Above_3000
select Country, sum(p.amount) as Revenue
from sakila.payment as p
join sakila.customer as c on p.customer_id = c.customer_id
join sakila.address as a on c.address_id = a.address_id
join sakila.city as ci on a.city_id = ci.city_id
join sakila.country as co on ci.country_id = co.country_id
group by co.country_id
having Revenue > 3000
order by Revenue DESC;