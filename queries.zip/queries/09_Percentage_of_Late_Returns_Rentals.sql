-- 09_Percentage_of_Late_Returns_Rentals
with All_Rentals as
(select customer_id from sakila.rental),
Late_Rentals as
(select r.customer_id 
from sakila.rental as r
join sakila.inventory as i on r.inventory_id = i.inventory_id
join sakila.film as f on i.film_id = f.film_id
where r.return_date is not null
and date(r.return_date) > date(date_add(r.rental_date, interval f.rental_duration day)))
select
(select count(*) from Late_Rentals) as Late_Rentals,
(select count(*) from All_Rentals) as All_Rentals,
round(
(select count(*) from Late_Rentals)/
(select count(*) from All_Rentals) * 100, 0)
as Late_Rate_Percent